credit=int(input("Introduceti valoarea creditului: "))
rata=float(input("Introduceti rata dobanzii: "))
timp=float(input("Introduceti perioada in ani: "))
dobanda=(credit*rata*timp)/100
print(f"Dobanda este {dobanda} ")