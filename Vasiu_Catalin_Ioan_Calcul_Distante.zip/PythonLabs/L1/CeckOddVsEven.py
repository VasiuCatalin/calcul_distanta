number=int(input("Introduceti un numar: "))
if number %2==0:
    print(f"{number} este par.")
else:
    print(f"{number} este impar.")