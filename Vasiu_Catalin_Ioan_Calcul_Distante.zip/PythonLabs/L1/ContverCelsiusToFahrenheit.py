celsius=float(input("Itroduceti temperatura in grade celsius: "))
fahrenheit=(celsius*1.8+32)
print(fahrenheit)