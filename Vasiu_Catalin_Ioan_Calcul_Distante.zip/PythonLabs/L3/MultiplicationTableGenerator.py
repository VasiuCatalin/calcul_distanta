def tabla_inmultirii(n):
    for i in range(1,11):
        print(n, 'x', i, '=', n*i)

numar=int(input("Introduceti un numar pentru a genera tabla inmultirii: "))

tabla_inmultirii(numar)